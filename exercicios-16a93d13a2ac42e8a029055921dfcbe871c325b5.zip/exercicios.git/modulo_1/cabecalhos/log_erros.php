[27-Dec-2016 10:22:34 America/Sao_Paulo] PHP Notice:  Undefined variable: asjhdkjas in /var/www/html/exercicios/modulo_1/cabecalhos/antiga.php on line 9
[27-Dec-2016 10:23:07 America/Sao_Paulo] PHP Notice:  Undefined variable: asjhdkjas in /var/www/html/exercicios/modulo_1/cabecalhos/antiga.php on line 9
[27-Dec-2016 10:23:08 America/Sao_Paulo] PHP Notice:  Undefined variable: asjhdkjas in /var/www/html/exercicios/modulo_1/cabecalhos/antiga.php on line 9
[27-Dec-2016 10:23:08 America/Sao_Paulo] PHP Notice:  Undefined variable: asjhdkjas in /var/www/html/exercicios/modulo_1/cabecalhos/antiga.php on line 9
[27-Dec-2016 10:23:10 America/Sao_Paulo] PHP Notice:  Undefined variable: asjhdkjas in /var/www/html/exercicios/modulo_1/cabecalhos/antiga.php on line 9
[27-Dec-2016 10:23:43 America/Sao_Paulo] PHP Notice:  Undefined variable: asjhdkjas in /var/www/html/exercicios/modulo_1/cabecalhos/antiga.php on line 9
[27-Dec-2016 10:23:43 America/Sao_Paulo] PHP Notice:  Undefined variable: asjhdkjas in /var/www/html/exercicios/modulo_1/cabecalhos/antiga.php on line 9
[27-Dec-2016 10:23:44 America/Sao_Paulo] PHP Notice:  Undefined variable: asjhdkjas in /var/www/html/exercicios/modulo_1/cabecalhos/antiga.php on line 9
[27-Dec-2016 16:04:24 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 16:10:06 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 16:10:59 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
