[27-Dec-2016 10:24:14 America/Sao_Paulo] PHP Notice:  Undefined variable: asjhdkjas in /var/www/html/exercicios/modulo_1/cabecalhos/antiga.php on line 9
[27-Dec-2016 15:16:22 America/Sao_Paulo] PHP Notice:  Undefined index: PHP_AUTH_USER in /var/www/html/exercicios/modulo_1/cabecalhos/autenticar.php on line 5
[27-Dec-2016 15:16:22 America/Sao_Paulo] PHP Notice:  Undefined index: PHP_AUTH_PW in /var/www/html/exercicios/modulo_1/cabecalhos/autenticar.php on line 5
[27-Dec-2016 15:38:07 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:39:11 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:41:24 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:42:50 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:43:11 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:43:54 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:44:36 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:44:58 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:48:55 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:49:45 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:49:46 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:49:47 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:49:58 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:51:57 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:53:23 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:54:56 America/Sao_Paulo] PHP Warning:  include(../Array2XML.php): failed to open stream: No such file or directory in /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php on line 3
[27-Dec-2016 15:54:56 America/Sao_Paulo] PHP Warning:  include(): Failed opening '../Array2XML.php' for inclusion (include_path='.:/usr/share/php') in /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php on line 3
[27-Dec-2016 15:54:56 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'Array2XML' not found in /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php:18
Stack trace:
#0 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php on line 18
[27-Dec-2016 15:55:15 America/Sao_Paulo] PHP Warning:  include(Array2XML.php): failed to open stream: No such file or directory in /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php on line 3
[27-Dec-2016 15:55:15 America/Sao_Paulo] PHP Warning:  include(): Failed opening 'Array2XML.php' for inclusion (include_path='.:/usr/share/php') in /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php on line 3
[27-Dec-2016 15:55:15 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'Array2XML' not found in /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php:18
Stack trace:
#0 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php on line 18
[27-Dec-2016 15:55:36 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:56:14 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:56:45 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:57:43 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:57:46 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 15:58:18 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 16:01:28 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 16:01:29 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
[27-Dec-2016 16:01:30 America/Sao_Paulo] PHP Fatal error:  Uncaught Error: Class 'DomDocument' not found in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php:46
Stack trace:
#0 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(140): Array2XML::init()
#1 /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php(58): Array2XML::getXMLRoot()
#2 /var/www/html/exercicios/modulo_1/cabecalhos/resposta.php(18): Array2XML::createXML('response', Array)
#3 {main}
  thrown in /var/www/html/exercicios/modulo_1/cabecalhos/Array2XML.php on line 46
