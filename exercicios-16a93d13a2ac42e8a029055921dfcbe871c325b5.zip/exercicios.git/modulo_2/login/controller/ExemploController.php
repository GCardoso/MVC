<?php 

include_once('controller/AbstractController.php');

class ExemploController extends AbstractController {

	function teste() {
		echo "aqui";
	}

	
}