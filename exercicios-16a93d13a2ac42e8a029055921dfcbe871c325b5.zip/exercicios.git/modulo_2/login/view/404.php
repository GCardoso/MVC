
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<h1>404</h1>
	<a href="login/entrar">ir pagina inical</a>
</body>
</html>