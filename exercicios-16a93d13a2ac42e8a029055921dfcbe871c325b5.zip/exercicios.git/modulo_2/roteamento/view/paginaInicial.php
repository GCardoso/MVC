<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Pagina inicial</title>
	<link rel="stylesheet" type="text/css" href="/../exercicios/modulo_1/bootstrap/css/bootstrap.min.css">
</head>
<body>
<legend><h1>Modulo_2-Roteamento</h1></legend>
<ul class="nav  nav-pills ">
  <li role="presentation" class="active"><a href="pessoa">Home</a></li>
  <li role="presentation"><a href="http://localhost/exercicios/modulo_2/roteamento/empresa/cadastrar">Empresa</a></li>
  <li role="presentation"><a href="http://localhost/exercicios/modulo_2/roteamento/pessoa/cadastrar">Pessoa</a></li>
  </ul>
</body>
</html>